NGOBROL — PROTOTIPE CHAT & STORY

Isi:
- index.html: aplikasi demo chat dan Story.
- Dapat dibuka langsung di browser, tanpa instalasi.
- Chat tersimpan di localStorage browser pada perangkat yang sama.
- Ini BELUM chat online: pengguna lain belum bisa menerima pesan.
- Story belum otomatis terhapus setelah 24 jam.
- Belum berupa APK Android.

CARA MENCOBA:
1. Ekstrak ZIP.
2. Buka folder ngobrol_chat_source.
3. Klik dua kali index.html untuk membukanya di Chrome.

CARA MENJADIKAN APK:
Untuk APK, situs ini perlu dibungkus dengan Android Studio (WebView/Capacitor) atau layanan pembungkus web tepercaya. Untuk chat online sungguhan, perlu backend seperti Firebase Authentication + Firestore, aturan keamanan, dan penyimpanan Story. Jangan masukkan kata sandi atau data pribadi ke prototipe ini.
